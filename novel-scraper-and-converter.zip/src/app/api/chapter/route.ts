import { NextRequest, NextResponse } from "next/server";
import { fetchChapterContent, type SourceType, type UniversalChapter } from "@/lib/scrapers";

export async function POST(request: NextRequest) {
  try {
    const { chapter, sourceType, sourceUrl } = await request.json();

    if (!chapter || !sourceType) {
      return NextResponse.json(
        { error: "chapter and sourceType are required" },
        { status: 400 }
      );
    }

    const result = await fetchChapterContent(
      chapter as UniversalChapter,
      sourceType as SourceType,
      { sourceUrl }
    );

    return NextResponse.json(result);
  } catch (error) {
    console.error("Chapter fetch error:", error);
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Failed to fetch chapter",
      },
      { status: 500 }
    );
  }
}
