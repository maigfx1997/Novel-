import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { novels, type NewNovel } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const allNovels = await db
      .select()
      .from(novels)
      .orderBy(desc(novels.createdAt));
    return NextResponse.json(allNovels);
  } catch (error) {
    console.error("Get novels error:", error);
    return NextResponse.json(
      { error: "Failed to fetch novels" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    const newNovel: NewNovel = {
      title: data.title,
      author: data.author || "",
      description: data.description || "",
      coverUrl: data.cover || data.coverUrl || "",
      sourceUrl: data.sourceUrl,
      sourceType: data.sourceType,
      totalChapters: data.chapters?.length || 0,
      chapters: data.chapters || [],
    };

    const [created] = await db.insert(novels).values(newNovel).returning();
    return NextResponse.json(created);
  } catch (error) {
    console.error("Create novel error:", error);
    return NextResponse.json(
      { error: "Failed to save novel" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await db.delete(novels).where(eq(novels.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete novel error:", error);
    return NextResponse.json(
      { error: "Failed to delete novel" },
      { status: 500 }
    );
  }
}
