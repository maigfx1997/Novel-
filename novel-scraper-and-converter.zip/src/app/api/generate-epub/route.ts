import { NextRequest, NextResponse } from "next/server";

export const maxDuration = 60;

interface ChapterData {
  title: string;
  content: string;
}

interface EpubOptions {
  title: string;
  author: string;
  description: string;
  cover?: string;
  chapters: ChapterData[];
}

export async function POST(request: NextRequest) {
  try {
    const options: EpubOptions = await request.json();

    if (!options.title || !options.chapters || options.chapters.length === 0) {
      return NextResponse.json(
        { error: "Title and chapters are required" },
        { status: 400 }
      );
    }

    // Dynamically import epub-gen-memory (CJS)
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const epubGenModule = require("epub-gen-memory");
    const epub = epubGenModule.default as (
      options: Record<string, unknown>,
      chapters: { title: string; content: string }[]
    ) => Promise<Buffer>;

    const chapters = options.chapters.map((ch) => ({
      title: ch.title,
      content: ch.content || `<p>لا يوجد محتوى</p>`,
    }));

    // Add description as first chapter if exists
    if (options.description) {
      chapters.unshift({
        title: "الوصف",
        content: `<div dir="rtl" style="text-align:right"><p>${options.description.replace(/\n/g, "<br/>")}</p></div>`,
      });
    }

    const epubOptions: Record<string, unknown> = {
      title: options.title,
      author: options.author || "Unknown",
      publisher: "Novel Converter",
      version: 3,
    };

    if (options.cover && options.cover.startsWith("http")) {
      epubOptions.cover = options.cover;
    }

    const buffer = await epub(epubOptions, chapters);

    return new NextResponse(buffer as unknown as ReadableStream, {
      status: 200,
      headers: {
        "Content-Type": "application/epub+zip",
        "Content-Disposition": `attachment; filename="${encodeURIComponent(options.title)}.epub"`,
        "Content-Length": String(buffer.length),
      },
    });
  } catch (error) {
    console.error("Generate EPUB error:", error);
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Failed to generate EPUB",
      },
      { status: 500 }
    );
  }
}
