import { NextRequest, NextResponse } from "next/server";
import * as cheerio from "cheerio";

interface ChapterData {
  title: string;
  content: string;
}

interface TxtOptions {
  title: string;
  author: string;
  description: string;
  chapters: ChapterData[];
}

function htmlToText(html: string): string {
  const $ = cheerio.load(html);
  $("script, style").remove();
  return $.text().replace(/\s+/g, " ").trim();
}

export async function POST(request: NextRequest) {
  try {
    const options: TxtOptions = await request.json();

    if (!options.title || !options.chapters || options.chapters.length === 0) {
      return NextResponse.json(
        { error: "Title and chapters are required" },
        { status: 400 }
      );
    }

    let text = `${options.title}\n`;
    text += `${"=".repeat(options.title.length)}\n\n`;
    text += `المؤلف: ${options.author || "غير معروف"}\n\n`;

    if (options.description) {
      text += `الوصف:\n${options.description}\n\n`;
      text += `${"─".repeat(50)}\n\n`;
    }

    for (const chapter of options.chapters) {
      text += `\n${chapter.title}\n`;
      text += `${"─".repeat(chapter.title.length)}\n\n`;
      text += `${htmlToText(chapter.content)}\n\n`;
    }

    const buffer = Buffer.from(text, "utf-8");

    return new NextResponse(buffer as unknown as ReadableStream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="${encodeURIComponent(options.title)}.txt"`,
        "Content-Length": String(buffer.length),
      },
    });
  } catch (error) {
    console.error("Generate TXT error:", error);
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Failed to generate TXT",
      },
      { status: 500 }
    );
  }
}
